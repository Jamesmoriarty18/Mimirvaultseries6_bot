---
name: Telegram webhook environments
description: Prevent development and production processes from disrupting one bot's global webhook.
---

Telegram stores one webhook per bot token, shared across all environments. When development and production use the same `TELEGRAM_BOT_TOKEN`, a development startup must never call `setWebhook` or `deleteWebhook`; either operation can replace the live production webhook.

**Why:** A development cleanup call intended to remove an inaccessible preview webhook can disable the production bot after publication.

**How to apply:** Let only the production process register the webhook. Development processes should skip all webhook mutations and leave the current Telegram configuration unchanged.
