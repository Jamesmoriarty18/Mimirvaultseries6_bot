import { type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowDown, ArrowRight, RotateCcw, ShieldCheck } from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [messages, setMessages] = useState([
    { from: 'bot', text: "Mortal. You stand before Mimir's Well of Wisdom. Gaze into its depths for remote-work scrolls, or speak your craft and claim your career runes. What currency of skill do you bring?", time: '09:41' },
  ]);
  const [premiumStep, setPremiumStep] = useState(0);
  const [toast, setToast] = useState('');
  const showToast = (text: string) => {
    setToast(text);
    window.setTimeout(() => setToast(''), 2600);
  };
  const freeScrolls = () => {
    setPremiumStep(0);
    setMessages((items) => [...items,
      { from: 'user', text: 'Gaze into the Scrolls', time: '09:42' },
      { from: 'bot', text: 'The Well yields these free scrolls, mortal. Each is open to your search:\\n\\n• We Work Remotely: https://weworkremotely.com/remote-jobs\\n• Remote OK: https://remoteok.com/\\n• Wellfound: https://wellfound.com/jobs\\n• Remotive: https://remotive.com/remote-jobs', time: '09:42' },
      { from: 'bot', text: 'These are free starting points, not endorsements. Read each listing closely and verify the employer before sharing personal details.', time: '09:42' },
    ]);
  };
  const premiumFlow = () => {
    setPremiumStep(1);
    setMessages((items) => [...items,
      { from: 'user', text: 'Unlock High-Tier Runes', time: '09:43' },
      { from: 'bot', text: 'The well is murky, and the high-tier runes lie beneath the mist. Offer 270 Telegram Stars for 30 days of premium career runes. The subscription renews automatically every 30 days until you cancel it in Telegram.', time: '09:43' },
      { from: 'bot', text: 'In Telegram, this opens a monthly invoice for the High-Tier Career Runes. This page is a preview only; no payment is connected.', time: '09:43' },
    ]);
  };
  const confirmPreview = () => {
    setPremiumStep(2);
    setMessages((items) => [...items,
      { from: 'user', text: 'Preview Stars checkout', time: '09:44' },
      { from: 'bot', text: 'The preview ends here. No Stars were requested, no payment was taken, and no rune was unlocked.', time: '09:44' },
    ]);
    showToast('Preview only — no charge has been made.');
  };
  const resetChat = () => {
    setPremiumStep(0);
    setMessages([
      { from: 'bot', text: "Mortal. You stand before Mimir's Well of Wisdom. Gaze into its depths for remote-work scrolls, or speak your craft and claim your career runes. What currency of skill do you bring?", time: '09:41' },
    ]);
  };
  return (
    <main className="site-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Mimir home">
          <span className="brand-mark">M</span>
          <span><span className="brand-name">Mimir</span><span className="brand-kicker">Remote work oracle</span></span>
        </a>
        <nav className="top-links" aria-label="Main navigation">
          <a href="#how">The way of the well</a>
          <a href="#preview">Bot preview</a>
          <a href="#pack">The resource pack</a>
          <a href="#preview" className="top-cta">Explore the preview <ArrowRight size={14} /></a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="eyebrow">A wiser way through the wilds of work</div>
          <h1>Find your work.<br />Keep your <em>worth.</em></h1>
          <p className="hero-description">Mimir is a guide for the remote-working age: a quiet source of real job leads, grounded career counsel, and the tools to move forward with intention.</p>
          <div className="hero-actions">
            <a className="button-primary" href="https://t.me/MimirVaultSeries6_bot" target="_blank" rel="noopener noreferrer" data-testid="link-open-telegram-bot">Open Mimir in Telegram <ArrowRight size={15} /></a>
            <a className="button-quiet" href="#how">How the well works <ArrowDown size={14} /></a>
          </div>
          <div className="hero-note">Telegram bot connected · @MimirVaultSeries6_bot</div>
        </div>
        <div className="hero-art" aria-label="Illustration of an ancient well beneath a Norse tree">
          <div className="rune-ring" aria-hidden="true">
            <span className="rune one">ᚨ</span><span className="rune two">ᚱ</span><span className="rune three">ᛗ</span><span className="rune four">ᛃ</span>
          </div>
          <svg className="well-illustration" viewBox="0 0 440 500" role="img" aria-label="A carved stone well and ancient tree">
            <defs>
              <linearGradient id="stone" x1="0" x2="1" y1="0" y2="1"><stop stopColor="#d2c4a7"/><stop offset="1" stopColor="#8f8c72"/></linearGradient>
              <linearGradient id="water" x1="0" x2="0" y1="0" y2="1"><stop stopColor="#859b89"/><stop offset="1" stopColor="#314b42"/></linearGradient>
            </defs>
            <path d="M213 324 C207 246 212 169 198 106 C188 63 171 39 153 16 C188 38 216 74 226 117 C236 70 267 38 304 21 C278 51 260 83 254 127 C247 190 259 256 256 324Z" fill="#435c49"/>
            <path d="M210 239 C160 188 116 174 72 171 C130 163 173 180 214 212 C189 154 166 128 132 105 C182 126 215 165 230 207 C243 158 280 118 328 98 C290 132 267 173 246 235Z" fill="#607458"/>
            <path d="M193 321 L183 250 L268 250 L257 321Z" fill="#665d4b"/>
            <path d="M128 300 Q220 267 312 300 L292 381 Q220 414 148 381Z" fill="url(#stone)" stroke="#696b58" strokeWidth="4"/>
            <ellipse cx="220" cy="300" rx="92" ry="30" fill="#7e806c" stroke="#5d6657" strokeWidth="5"/>
            <ellipse cx="220" cy="301" rx="70" ry="19" fill="url(#water)"/>
            <path d="M166 301 Q192 292 221 301 T276 301" fill="none" stroke="#c1b991" strokeWidth="2" opacity=".78"/>
            <path d="M151 330 Q219 351 289 330 M156 354 Q218 375 282 354" fill="none" stroke="#a7a18a" strokeWidth="3" opacity=".8"/>
            <path d="M126 296 L121 270 Q220 237 319 270 L314 296" fill="none" stroke="#534f41" strokeWidth="8"/>
            <path d="M120 267 Q220 232 320 267" fill="none" stroke="#9e8f6b" strokeWidth="7"/>
            <path d="M145 385 L134 409 Q220 444 306 409 L295 385" fill="#726e5a" stroke="#555c4e" strokeWidth="3"/>
            <path d="M86 427 Q220 405 354 427" fill="none" stroke="#9a8a68" strokeWidth="2" opacity=".7"/>
            <path d="M125 439 Q220 422 315 439" fill="none" stroke="#aaa07f" strokeWidth="1" opacity=".65"/>
            <circle cx="220" cy="299" r="8" fill="#d0b078" opacity=".7"/>
          </svg>
          <div className="art-caption">At the root of the world, a well remembers every path.</div>
        </div>
      </section>

      <hr className="section-rule" />
      <section className="preview-section" id="preview">
        <div className="preview-layout">
          <div className="preview-copy">
            <div className="section-label">A small window into the well</div>
            <h2>See what Mimir has to say.</h2>
            <p>Begin with the greeting, ask for free job-search scrolls, or step through the premium Stars flow. This interactive conversation is a faithful preview—not a live Telegram bot and not a checkout.</p>
            <ul className="preview-list">
              <li><span className="list-mark">I</span><span>Start with the bot's welcome and choose your path.</span></li>
              <li><span className="list-mark">II</span><span>Browse practical, public starting points for remote roles.</span></li>
              <li><span className="list-mark">III</span><span>Inspect the Stars invoice flow without any charge.</span></li>
            </ul>
            <div className="hero-actions">
              <button className="button-quiet" type="button" onClick={resetChat} data-testid="button-reset-chat"><RotateCcw size={14} /> Restart conversation</button>
            </div>
          </div>
          <div className="phone-wrap">
            <div className="preview-stamp">Interactive preview · no payment</div>
            <div className="phone-shadow" />
            <div className="phone">
              <div className="phone-notch" />
              <div className="phone-status"><span>9:41</span><span>TELEGRAM PREVIEW</span></div>
              <div className="telegram-head">
                <div className="bot-avatar">M</div>
                <div><div className="bot-title">Mimir · Career guide</div><div className="bot-online">preview conversation</div></div>
              </div>
              <div className="chat-body" aria-live="polite" data-testid="status-chat-messages">
                <div className="chat-day">The well is open</div>
                {messages.map((message, index) => (
                  <div key={`${message.time}-${index}`} className={`message ${message.from === 'user' ? 'user' : ''}`} data-testid={`text-chat-message-${index}`}>
                    {message.text.split('\n').map((line, lineIndex) => <span key={lineIndex}>{line}{lineIndex < message.text.split('\n').length - 1 && <br />}</span>)}
                    <small>{message.time}</small>
                  </div>
                ))}
                {premiumStep === 1 && <div className="message" data-testid="status-payment-preview"><strong>Monthly Stars invoice · preview</strong><br />Career Resource Pack<br /><strong>270 Stars / 30 days</strong><br /><span>Automatically renews every 30 days until canceled in Telegram. Preview only; nothing will be charged.</span><small>09:43</small></div>}
                {premiumStep === 2 && <div className="message"><strong>Preview ended safely.</strong><br />No payment made.<small>09:44</small></div>}
              </div>
              <div className="keyboard">
                {premiumStep === 1 ? (
                  <button type="button" className="premium-key" onClick={confirmPreview} data-testid="button-preview-checkout">Preview Stars checkout — no charge</button>
                ) : (
                  <>
                    <button type="button" onClick={freeScrolls} data-testid="button-free-scrolls">📜 Gaze into the Scrolls</button>
                    <button type="button" className="premium-key" onClick={premiumFlow} data-testid="button-premium-runes">💎 Unlock High-Tier Runes</button>
                  </>
                )}
              </div>
              <div className="phone-foot"><ShieldCheck size={10} /> Preview only · no payment connection</div>
            </div>
          </div>
        </div>
      </section>

      <section className="feature-band" id="how">
        <div className="feature-grid">
          <article className="feature"><div className="feature-num">01 / FIND</div><h3>Leads worth your time</h3><p>Discover reputable public job boards and remote-first opportunities without the noise or false promises.</p></article>
          <article className="feature"><div className="feature-num">02 / PREPARE</div><h3>Wisdom you can use</h3><p>Turn a daunting search into clear next steps for your profile, applications, interviews, and conversations.</p></article>
          <article className="feature"><div className="feature-num">03 / MOVE</div><h3>Your work, on your terms</h3><p>Build a sustainable path toward remote work with practical guidance rooted in care and discernment.</p></article>
        </div>
      </section>

      <section className="pack-section" id="pack">
        <div className="pack-card">
          <div className="pack-copy">
            <div className="section-label">For the deeper crossing</div>
            <h2>The Career<br />Resource Pack.</h2>
            <p>A considered set of tools for the moments that matter: when you are shaping your story, choosing where to apply, or preparing to ask for more.</p>
            <a className="button-primary" href="#preview">Preview the Stars flow <ArrowRight size={14} /></a>
          </div>
          <div className="pack-items">
            <p>What the pack is designed to hold</p>
            <ul>
              <li>Focused job-search system <span>FIELD GUIDE</span></li>
              <li>CV and profile prompts <span>WORKSHEET</span></li>
              <li>Interview preparation <span>QUESTION SET</span></li>
              <li>Salary conversation guide <span>REFERENCE</span></li>
            </ul>
          </div>
        </div>
      </section>
      <footer className="footer">
        <span className="footer-brand">Mimir, keeper of the well</span>
        <span>Built for the long road to better work.</span>
        <a href="#top">Return to the beginning ↑</a>
      </footer>
      <div className={`toast-note ${toast ? 'show' : ''}`} role="status" data-testid="status-toast">{toast}</div>
    </main>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
