import { createHmac, timingSafeEqual } from "node:crypto";
import { Router, type IRouter } from "express";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const SCROLLS_BUTTON = "📜 Gaze into the Scrolls";
const RUNES_BUTTON = "💎 Unlock High-Tier Runes";
const MONTHLY_INVOICE_PAYLOAD = "mimir-high-tier-runes-monthly-v1";
const LEGACY_INVOICE_PAYLOAD = "mimir-high-tier-runes-v1";
const LEGACY_STARS_AMOUNT = 25;
const DEFAULT_STARS_AMOUNT = 270;
const MONTHLY_SUBSCRIPTION_PERIOD = 30 * 24 * 60 * 60;

const freeScrolls = [
  {
    name: "We Work Remotely",
    url: "https://weworkremotely.com/remote-jobs",
  },
  { name: "Remote OK", url: "https://remoteok.com/" },
  { name: "Wellfound", url: "https://wellfound.com/jobs" },
  { name: "Remotive", url: "https://remotive.com/remote-jobs" },
];

const premiumRunes = [
  { name: "Arc", url: "https://arc.dev/remote-jobs" },
  { name: "Himalayas", url: "https://himalayas.app/jobs" },
  { name: "Remote.co", url: "https://remote.co/remote-jobs/" },
  { name: "Working Nomads", url: "https://www.workingnomads.com/jobs" },
];

interface TelegramMessage {
  chat?: { id: number };
  text?: string;
  successful_payment?: {
    currency: string;
    total_amount: number;
    invoice_payload: string;
    telegram_payment_charge_id: string;
    is_recurring?: boolean;
    is_first_recurring?: boolean;
    subscription_expiration_date?: number;
  };
}

interface TelegramUpdate {
  message?: TelegramMessage;
  pre_checkout_query?: {
    id: string;
    currency: string;
    total_amount: number;
    invoice_payload: string;
  };
}

function getBotToken(): string | undefined {
  return process.env.TELEGRAM_BOT_TOKEN?.trim() || undefined;
}

function getStarsAmount(): number {
  const configuredAmount = Number(process.env.MIMIR_STARS_AMOUNT);
  if (
    Number.isSafeInteger(configuredAmount) &&
    configuredAmount > 0 &&
    configuredAmount <= 100_000
  ) {
    return configuredAmount;
  }
  return DEFAULT_STARS_AMOUNT;
}

function getWebhookSecret(token: string): string {
  return createHmac("sha256", token).update("mimir-telegram-webhook").digest("hex");
}

async function telegramRequest<T>(
  token: string,
  method: string,
  body: Record<string, unknown>,
): Promise<T> {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });

  const result = (await response.json()) as {
    ok?: boolean;
    result?: T;
    description?: string;
  };

  if (!response.ok || !result.ok) {
    throw new Error(result.description || `Telegram ${method} request failed`);
  }

  return result.result as T;
}

const persistentKeyboard = {
  keyboard: [[{ text: SCROLLS_BUTTON }], [{ text: RUNES_BUTTON }]],
  is_persistent: true,
  resize_keyboard: true,
  input_field_placeholder: "Speak to the well...",
};

async function sendMessage(
  token: string,
  chatId: number,
  text: string,
): Promise<void> {
  await telegramRequest(token, "sendMessage", {
    chat_id: chatId,
    text,
    reply_markup: persistentKeyboard,
    link_preview_options: { is_disabled: true },
  });
}

async function sendScrolls(token: string, chatId: number): Promise<void> {
  const list = freeScrolls
    .map((scroll) => `• ${scroll.name}: ${scroll.url}`)
    .join("\n");

  await sendMessage(
    token,
    chatId,
    `The Well yields these free scrolls, mortal. Each is open to your search:\n\n${list}\n\nChoose a scroll and seek work worthy of your craft.`,
  );
}

async function sendRunesInvoice(token: string, chatId: number): Promise<void> {
  const amount = getStarsAmount();
  await sendMessage(
    token,
    chatId,
    `The well is murky, and the high-tier runes lie beneath the mist. Offer ${amount} Telegram Stars for 30 days of premium career runes. The subscription renews automatically every 30 days until you cancel it in Telegram. Your first tribute clears the mist and reveals the Career Resource Pack.`,
  );

  await telegramRequest(token, "sendInvoice", {
    chat_id: chatId,
    title: "High-Tier Career Runes",
    description:
      "Monthly access to Mimir's premium remote-career resources. Renews every 30 days until canceled in Telegram.",
    payload: MONTHLY_INVOICE_PAYLOAD,
    provider_token: "",
    currency: "XTR",
    prices: [{ label: "Career Runes · monthly", amount }],
    subscription_period: MONTHLY_SUBSCRIPTION_PERIOD,
    start_parameter: "mimir-monthly-career-runes",
  });
}

async function sendPremiumRunes(
  token: string,
  chatId: number,
  payment: NonNullable<TelegramMessage["successful_payment"]>,
): Promise<void> {
  const list = premiumRunes
    .map((rune) => `• ${rune.name}: ${rune.url}`)
    .join("\n");
  const paymentNotice = payment.is_recurring
    ? payment.is_first_recurring
      ? "Your monthly subscription is active. Mimir will send these runes again when Telegram renews it."
      : "Your monthly tribute has renewed. Here is this month's Career Resource Pack."
    : "The tribute is accepted. The mist parts.";

  await sendMessage(
    token,
    chatId,
    `${paymentNotice}\n\nYour Career Resource Pack:\n\n1. Focused search system: choose two target role titles, shortlist ten companies, and track each application from research through follow-up. Tailor every application to the role instead of sending the same CV everywhere.\n\n2. CV and profile prompts: lead with your target role and strongest proof of impact. Shape each CV bullet as action + context + measurable result. Replace vague claims with evidence.\n\n3. Interview preparation: prepare five concise examples using situation, task, action, and result. Ask the employer how success is measured and how the team works across time zones.\n\n4. Salary conversations: research pay for the role and hiring location, decide your target and minimum before the call, and ask for the employer's range before naming a figure.\n\nFurther job-board scrolls:\n${list}\n\nVerify each employer, and never pay a recruiter for access to a job.`,
  );
}

async function handlePreCheckout(
  token: string,
  query: NonNullable<TelegramUpdate["pre_checkout_query"]>,
): Promise<void> {
  const valid =
    query.currency === "XTR" &&
    ((query.invoice_payload === MONTHLY_INVOICE_PAYLOAD &&
      query.total_amount === getStarsAmount()) ||
      (query.invoice_payload === LEGACY_INVOICE_PAYLOAD &&
        query.total_amount === LEGACY_STARS_AMOUNT));

  await telegramRequest(token, "answerPreCheckoutQuery", {
    pre_checkout_query_id: query.id,
    ok: valid,
    ...(!valid
      ? {
          error_message:
            "The tribute does not match the promised rune. No Stars have been taken.",
        }
      : {}),
  });
}

async function handleUpdate(token: string, update: TelegramUpdate): Promise<void> {
  if (update.pre_checkout_query) {
    await handlePreCheckout(token, update.pre_checkout_query);
    return;
  }

  const message = update.message;
  const chatId = message?.chat?.id;
  if (!message || chatId === undefined) return;

  const payment = message.successful_payment;
  if (payment) {
    if (
      payment.currency === "XTR" &&
      ((payment.invoice_payload === MONTHLY_INVOICE_PAYLOAD &&
        payment.total_amount === getStarsAmount()) ||
        (payment.invoice_payload === LEGACY_INVOICE_PAYLOAD &&
          payment.total_amount === LEGACY_STARS_AMOUNT))
    ) {
      await sendPremiumRunes(token, chatId, payment);
    } else {
      logger.warn(
        { currency: payment.currency, totalAmount: payment.total_amount },
        "Received a Telegram Stars payment that did not match the Mimir invoice",
      );
      await sendMessage(
        token,
        chatId,
        "The tribute reached the Well, but its rune does not match this offering. Contact the bot owner before making another payment.",
      );
    }
    return;
  }

  const text = message.text?.trim();
  if (!text) return;

  if (/^\/start(?:@\w+)?(?:\s|$)/i.test(text)) {
    await sendMessage(
      token,
      chatId,
      "Mortal. You stand before Mimir's Well of Wisdom. Gaze into its depths for remote-work scrolls, or speak your craft and claim your career runes. What currency of skill do you bring?",
    );
    return;
  }

  if (text === SCROLLS_BUTTON) {
    await sendScrolls(token, chatId);
    return;
  }

  if (text === RUNES_BUTTON) {
    await sendRunesInvoice(token, chatId);
    return;
  }

  await sendMessage(
    token,
    chatId,
    "The Well hears you, mortal. Name your skills, or choose one of the two scrolls below to continue your quest.",
  );
}

function resolveWebhookUrl(): string | undefined {
  if (process.env.NODE_ENV !== "production") return undefined;

  const explicitUrl = process.env.MIMIR_WEBHOOK_URL?.trim();
  if (explicitUrl) {
    try {
      const url = new URL(explicitUrl);
      return url.protocol === "https:" ? url.toString() : undefined;
    } catch {
      return undefined;
    }
  }

  const host = process.env.REPLIT_DOMAINS?.split(",")[0]?.trim();
  if (!host) return undefined;

  const normalizedHost = host.replace(/^https?:\/\//, "").replace(/\/+$/, "");
  return `https://${normalizedHost}/api/telegram/webhook`;
}

router.post("/telegram/webhook", async (req, res): Promise<void> => {
  const token = getBotToken();
  if (!token) {
    res.status(503).json({ error: "Telegram bot is not configured" });
    return;
  }

  const expectedSecret = Buffer.from(getWebhookSecret(token));
  const suppliedSecret = Buffer.from(
    req.get("x-telegram-bot-api-secret-token") ?? "",
  );
  if (
    suppliedSecret.length !== expectedSecret.length ||
    !timingSafeEqual(suppliedSecret, expectedSecret)
  ) {
    res.sendStatus(401);
    return;
  }

  try {
    await handleUpdate(token, req.body as TelegramUpdate);
    res.sendStatus(200);
  } catch {
    req.log.error("Failed to process Telegram bot update");
    res.sendStatus(500);
  }
});

export async function configureTelegramWebhook(): Promise<void> {
  const token = getBotToken();
  if (!token) {
    logger.info("Telegram bot is idle until TELEGRAM_BOT_TOKEN is configured");
    return;
  }

  const url = resolveWebhookUrl();
  if (!url) {
    if (process.env.NODE_ENV !== "production") {
      logger.info(
        "Skipping Telegram webhook registration in development; the existing bot webhook is left unchanged",
      );
      return;
    }

    logger.warn(
      "Telegram bot token is configured, but no public HTTPS webhook URL is available",
    );
    return;
  }

  try {
    await telegramRequest(token, "setWebhook", {
      url,
      secret_token: getWebhookSecret(token),
      allowed_updates: ["message", "pre_checkout_query"],
    });
    const webhookInfo = await telegramRequest<{
      pending_update_count?: number;
      last_error_date?: number;
      last_error_message?: string;
    }>(token, "getWebhookInfo", {});
    const lastDeliveryError = webhookInfo.last_error_message
      ?.replaceAll(token, "[redacted]")
      .slice(0, 300);
    const webhookHost = new URL(url).host;

    if (lastDeliveryError) {
      logger.warn(
        {
          webhookHost,
          pendingUpdates: webhookInfo.pending_update_count ?? 0,
          lastErrorDate: webhookInfo.last_error_date,
          lastDeliveryError,
        },
        "Telegram reports a webhook delivery error",
      );
    } else {
      logger.info(
        {
          webhookHost,
          pendingUpdates: webhookInfo.pending_update_count ?? 0,
        },
        "Mimir Telegram webhook registered with no delivery error",
      );
    }
  } catch (error) {
    logger.error(
      {
        reason:
          error instanceof Error
            ? error.message.replaceAll(token, "[redacted]").slice(0, 300)
            : "Unknown Telegram API error",
      },
      "Could not verify the Mimir Telegram webhook",
    );
  }
}

export default router;
